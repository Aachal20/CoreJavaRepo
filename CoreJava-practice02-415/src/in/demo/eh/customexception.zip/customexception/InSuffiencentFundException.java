package in.demo.eh.customexception;

public class InSuffiencentFundException extends Exception {
	
public InSuffiencentFundException() {
	super();
}

public InSuffiencentFundException(String msg) {
	super(msg);
}
}
