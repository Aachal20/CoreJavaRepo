package in.demo.eh.customexception;

public class InValidAmountException extends Exception {
	public InValidAmountException() {
		super();
	}

	public InValidAmountException(String msg) {
		super(msg);
	}
}
