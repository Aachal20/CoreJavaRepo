package in.demo.eh;

public class Test01_NormalExceution {
	

public static void main(String[] args) {
	
	  int a = 20;
	  int b = 10;
	  System.out.println("Value of a is :: " +a);
	  System.out.println("Value of b is :: " +b);
	  
	  int c = a/b;
	  System.out.println("Value of c is :: " +c);

	}

}
