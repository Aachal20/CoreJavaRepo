package in.demo.eh;

public class Test07_Example{

	public static void main(String[] args) {
		//Test07 test = new Test07();
		//test.m1();
		
		//Test08 test1 = new Test08();
		//test1.m2();
		

		//Test09 test2 = new Test09();
		//test2.m1();
		
		
		//Test10 test10 = new Test10();
		//test10.m2();
		
		//Test11 test11 = new Test11();
		//test11.m2();
		
		Test12 test12 = new Test12();
		test12.m2();
		

	}

}
