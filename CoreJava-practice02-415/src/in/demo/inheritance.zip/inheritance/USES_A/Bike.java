package in.demo.inheritance.USES_A;

public class Bike {
	 
     String bikeNumber;  
     String bikeNAme;  
    
    
}  