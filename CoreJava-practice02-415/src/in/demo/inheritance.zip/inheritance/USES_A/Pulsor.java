package in.demo.inheritance.USES_A;
//https://www.studytonight.com/java/aggregation.php
public class Pulsor extends Bike {
	
	 public void PulsarStartDemo()  
	    {  
	        Engine PulsarEngine = new Engine();  
	        PulsarEngine.stop();  
	    }  
}
