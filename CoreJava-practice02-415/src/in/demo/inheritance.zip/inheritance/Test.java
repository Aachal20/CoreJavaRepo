package in.demo.inheritance;

import in.demo.inheritance.Example;

public class Test {

	public static void main(String[] args) {
		//Has-A relation
		Example e1 = new Example();
		System.out.println(e1.a);
         System.out.println(e1.x);
	}

}
