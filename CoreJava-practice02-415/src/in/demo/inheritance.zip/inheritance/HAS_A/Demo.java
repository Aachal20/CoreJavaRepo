package in.demo.inheritance.HAS_A;

public class Demo {
	 public static void main(String[] args)  
	 {  
		 Pulsor  myPulsar = new Pulsor();  
	        myPulsar.setColor("BLACK");  
	        myPulsar.setMaxSpeed(136);  
	        myPulsar.bikeInfo();  
	       myPulsar.PulsarStartDemo();  
	    }
}
