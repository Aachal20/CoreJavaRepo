package in.demo.inheritance;

public class Example {
 
	static int a = 10;
	int x = 20;
	
	static void m1() {
		System.out.println("Example m1");
	}
	void m2() {
		System.out.println("Example m2");
	}
}
