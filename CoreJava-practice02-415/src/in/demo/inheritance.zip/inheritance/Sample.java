package in.demo.inheritance;
//Is-A relation
public class Sample extends Example {

	public static void main(String[] args) {
		
		System.out.println(a);
		m1();

		Sample s1 = new Sample();
		System.out.println(s1.x);
		s1.m2();
	}
}
